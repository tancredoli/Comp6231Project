package Model;

public enum RMAddressInfo {
	RM_ADDRESS_INFO;
//	public final String RM1address = "172.20.10.3";
//	public final String RM2address = "172.20.10.2";
//	public final String RM3address = "172.20.10.5";
    public final String RM1address = "localhost";
	public final String RM2address = "localhost";
	public final String RM3address = "localhost";
}
