package Model;

public enum FEPort {
	FE_PORT;
	public final int FEPort = 5555;
	public final int RegistorPort = 5554;
}
