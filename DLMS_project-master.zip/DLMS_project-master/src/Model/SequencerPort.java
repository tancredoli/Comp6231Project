package Model;

public enum SequencerPort {
	SEQUENCER_PORT;
	public final int sequencerPort = 4894;
}
