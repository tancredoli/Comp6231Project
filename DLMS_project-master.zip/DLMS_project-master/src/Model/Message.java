package Model;

/**
 * Created by liaoxiaoyun on 2019-03-21.
 */
public class Message {
   public int seqId = 0;
   public String feHostAddr = "";
   public String libCode = "";
   public String operationMsg = "";
}
