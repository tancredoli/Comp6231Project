package Model;

public enum ReplicaPort {
	REPLICA_PORT;
	public final int replica1 = 9906;
	public final int replica2 = 9907;
	public final int replica3 = 9908;
}
