package Host1;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class ClientTest{

	public static void main(String args[]){
		String addr = "132.205.94.10,6000";
		String msg = "0:" + addr + ":addEvent,MTLM1001,MTLA100519,2,10";
		String msg1 = "1:" + addr + ":addEvent,OTWM1001,OTWA100519,2,10";
		String msg2 = "2:" + addr + ":addEvent,TORM1001,TORA100519,2,10";
		String msg3 = "3:" + addr + ":listEventAvailability,MTLM1001,2";
		UDP(msg);
		UDP(msg1);
		UDP(msg2);
		UDP(msg3);
		
	}
	
	public static void UDP(String msg) {
		DatagramSocket socket = null;
		String hostname = "132.205.94.10";
		int serverPort = 6666;
		String result = "";
		try {
			socket = new DatagramSocket(5000);
			// use UDP to check the valid of account.
//			while(true) {
				byte[] message = (msg.getBytes());
				InetAddress Host = InetAddress.getByName(hostname);// the address of the client is equal to the server
				DatagramPacket request = new DatagramPacket(message, message.length, Host, serverPort);
				socket.send(request);
				
				
//				byte[] buffer = new byte[1000];
//				DatagramPacket reply = new DatagramPacket(buffer, buffer.length);
//				socket.receive(reply);
//				result = new String(reply.getData()).trim();
//				System.out.println(result);
//			}
		} catch (Exception e) {
			System.out.println("Socket: " + e.getMessage());
		} finally {
			if (socket != null) {
				socket.close();
			}
		}
//		return result;
	}

}
