package Host1;

import java.io.IOException;
import java.util.Queue;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;

import Model.*;

public class Replica1 {

	public Logger log;
	public Server_MTL MTL;
	public Server_OTW OTW;
	public Server_TOR TOR;
	// public boolean bugFree = true;
	// public boolean crashFree = true;
	public Queue<Message> historyQueue;

//	public Replica1(Server_MTL MTL, Server_OTW OTW, Server_TOR TOR) {
//		super();
//		// this.log = log;
//		this.MTL = MTL;
//		this.OTW = OTW;
//		this.TOR = TOR;
//	}

	public Replica1() {
		try {

			// Logger conserver1_log = Logger.getLogger("conserver1.log");
			// createLogger("conserver1.log", conserver1_log);
			//
			// Logger mcgserver1_log = Logger.getLogger("mcgserver1_log");
			// createLogger("mcgserver1.log", mcgserver1_log);
			//
			// Logger monserver1_log = Logger.getLogger("monserver1.log");
			// createLogger("monserver1.log", monserver1_log);

			MTL = new Server_MTL();
			OTW = new Server_OTW();
			TOR = new Server_TOR();

			Thread t1 = new Thread(MTL);
			Thread t2 = new Thread(OTW);
			Thread t3 = new Thread(TOR);
			
			t1.start();
			t2.start();
			t3.start();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String executeMsg(Message msg) {
		String result = "";
		String operation[] = msg.operationMsg.split(",");
		Server_interface server = null;
		String userId = operation[1].substring(0, 3);
		if (userId.equalsIgnoreCase("MTL"))
			server = MTL;
		else if (userId.equalsIgnoreCase("OTW"))
			server = OTW;
		else if (userId.equalsIgnoreCase("TOR"))
			server = TOR;
		switch (operation[0]) {
		case ("addEvent"):
			result = server.addEvent(operation[1], operation[2], operation[3], Integer.parseInt(operation[4]));
			break;
		case ("removeEvent"):
			result = server.removeEvent(operation[1], operation[2], operation[3]);
			break;
		case ("listEventAvailability"):
			result = server.listEventAvailability(operation[1], operation[2]);
			break;
		case ("bookEvent"):
			result = server.bookEvent(operation[1], operation[2], operation[3]);
			break;
		case ("getBookingSchedule"):
			result = server.getBookingSchedule(operation[1]);
			break;
		case ("cancelEvent"):
			result = server.cancelEvent(operation[1], operation[3], operation[2]);
			break;
		case ("swapEvent"):
			result = server.swapEvent(operation[1], operation[2], operation[3], operation[4], operation[5]);
			break;

		default:
			System.out.println("Invalid input please try again.");
			break;
		}
		return result;
	}

//	public void fixBug() {
//		conServer.bugFree = true;
//		mcgServer.bugFree = true;
//		monServer.bugFree = true;
//		bugFree = true;
//	}
//
//	public void setBug() {
//		conServer.bugFree = false;
//		mcgServer.bugFree = false;
//		monServer.bugFree = false;
//		bugFree = false;
//	}

//	private static void createLogger(String log_name, Logger logger) throws IOException {
//		logger.setLevel(Level.ALL);
//		FileHandler handler = new FileHandler(log_name);
//		handler.setFormatter(new logSetFormatter());
//		logger.addHandler(handler);
//	}

//	public void recoverRplicaData() {
//		while (historyQueue.size() > 0) {
//			Message msg = historyQueue.poll();
//			System.out.println("recover --- " + msg.operationMsg);
//			executeMsg(msg);
//		}
//	}

//	public void startServers() {
//		Runnable start_CON_UDP = () -> {
//			try {
//				conServer.udpServer();
//			} catch (Exception e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		};
//
//		Runnable start_MCG_UDP = () -> {
//			try {
//				mcgServer.udpServer();
//
//			} catch (Exception e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		};
//
//		Runnable start_MON_UDP = () -> {
//			try {
//				monServer.udpServer();
//			} catch (Exception e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		};
//
//		Thread Thread2 = new Thread(start_CON_UDP);
//		Thread Thread3 = new Thread(start_MCG_UDP);
//		Thread Thread4 = new Thread(start_MON_UDP);
//		// Thread Thread5 = new Thread(failureListener);
//
//		// Thread1.start();
//		Thread2.start();
//		Thread3.start();
//		Thread4.start();
//	}
//
//	public void closeImpSocket() {
//		MTL.aSocket.close();
//		OTW.aSocket.close();
//		TOR.aSocket.close();
//	}
}
