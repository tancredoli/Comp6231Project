package Model;

public class Message {
	public int seqId = 0;
	public String FEAddr = "";
	public String FEPort = "";
	public String operationMsg = "";
}
