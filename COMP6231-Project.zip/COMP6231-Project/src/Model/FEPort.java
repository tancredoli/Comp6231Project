package Model;

public class FEPort {
	
	public final String FEAddress = "132.205.229.222";
	public final int FEPort = 5000;
	public final int RegistorPort = 5554;
}
