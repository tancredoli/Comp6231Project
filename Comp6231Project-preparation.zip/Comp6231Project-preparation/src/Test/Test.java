package Test;

import java.util.ArrayList;
import java.util.Iterator;

import Utility.Constants;

/**
 * @Author: Rui
 * @Description:
 * @Date: Created in 3:05 PM 2019-07-16
 * @Modified by:
 */
public class Test {
    public static void main(String[] args) {
	ArrayList<String> rsList = new ArrayList<>();
	rsList.add("1!F");
	rsList.add("1!F");
	rsList.add("1!");
	rsList.add("1!F");

	Test test = new Test();
	// boolean tes1 = test.checkErrType(rsList);
	test.multicastFailure(rsList);
	// if (tes1) {
	// System.out.println("t");
	// } else {
	// System.out.println("f");
	// }

	// String teString =
	// "1-MTLA100519,2-OTWA100519,3-TORA100519,1-MTLE100519,1-OTWA130519";
	// System.out.println(unitFormat(teString));
    }

    private void multicastFailure(ArrayList<String> tfList) {
	// TODO Auto-generated method stub
	int fail_num = -1;
	int fail_seq = -1;

	fail_num = tfList.indexOf(findWrong(tfList)) + 1;
	String temp = findWrong(tfList);
	String[] temp_arr = temp.split(Constants.separator_sup);
	fail_seq = Integer.parseInt(temp_arr[0]);
	System.out.println(fail_seq);
	System.out.println(fail_num);

    }

    String findWrong(ArrayList<String> rsList) {

	String majorStr = findMajority(rsList);

	Iterator<String> iterator = rsList.iterator();
	while (iterator.hasNext()) {
	    String temp = iterator.next();
	    if (!temp.equals(majorStr)) {
		return temp;
	    }
	}

	return majorStr;
    }

    private boolean checkErrType(ArrayList<String> rsList) {
	// TODO Auto-generated method stub

	ArrayList<String> list = new ArrayList<>();
	Iterator<String> itr = rsList.iterator();
	while (itr.hasNext()) {
	    String string = itr.next();
	    list.add(string);
	}
	itr = list.iterator();
	String item1 = rsList.get(0);
	while (itr.hasNext()) {
	    if (itr.next().equals(""))
		itr.remove();
	}
	String string = list.get(0);
	itr = list.iterator();
	while (itr.hasNext()) {
	    if (itr.next().equals(string))
		;
	    else {
		return false;
	    }
	}
	return true;
    }

    private static String unitFormat(String rspStr) {
	// TODO Auto-generated method stub

	ArrayList<String> aList = new ArrayList<>();
	String[] strArr = rspStr.split(",");
	for (int i = 0; i < strArr.length; i++) {
	    aList.add(strArr[i]);

	}
	aList.sort(null);
	return aList.toString();
    }

    String findMajority(ArrayList<String> rsList) {

	int size = rsList.size();
	double max;
	if (size % 2 == 0) {

	    max = Math.floorDiv(rsList.size(), 2);
	} else {
	    max = Math.floorDiv(rsList.size(), 2) + 1;
	}
	System.out.println(max);

	String failstr = "no_result";

	for (int i = 0; i < rsList.size(); i++) {
	    int count = 0;
	    Iterator<String> iterator = rsList.iterator();
	    while (iterator.hasNext()) {
		String cur = iterator.next();
		if (cur.equals(rsList.get(i))) {
		    count++;
		}
	    }

	    if (count >= max) {
		return rsList.get(i).trim();
	    }

	}

	return failstr;
    }
}
