package Test;

import org.omg.CORBA.ORB;
import org.omg.CORBA.ORBPackage.InvalidName;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;
import org.omg.CosNaming.NamingContextPackage.CannotProceed;
import org.omg.CosNaming.NamingContextPackage.NotFound;

import FEInterface.CommonInterface;
import FEInterface.CommonInterfaceHelper;

public class TestFailure {

    private String customerID;
    private String userID;
    private String eventID;
    private int eventType;
    private int bookingCapacity;

    public TestFailure(String userID, String eventID, int eventType, int bookingCapacity) {
	// TODO Auto-generated constructor stub
	this.userID = userID;
	this.eventID = eventID;
	this.eventType = eventType;
	this.bookingCapacity = bookingCapacity;

    }

    public static void main(String[] args) {
	ORB orb = ORB.init(args, null);
	org.omg.CORBA.Object objRef = null;

	try {
	    objRef = orb.resolve_initial_references("NameService");
	    NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);
	    CommonInterface obj = CommonInterfaceHelper.narrow(ncRef.resolve_str("frontend"));
	    String customerID = "MTLM0001";
	    Runnable runnable1 = new Runnable() {
		@Override
		public void run() {
		    System.out.println(obj.addEvent(customerID, "MTLM190324", 1, 10));
		}
	    };
	    Runnable runnable2 = new Runnable() {
		@Override
		public void run() {
		    System.out.println(obj.addEvent(customerID, "MTLM120324", 1, 10));
		}
	    };
	    Runnable runnable3 = new Runnable() {
		@Override
		public void run() {
		    System.out.println(obj.addEvent(customerID, "MTLM130324", 1, 10));
		}
	    };
	    new Thread(runnable1).start();
	    new Thread(runnable2).start();
	    new Thread(runnable3).start();
	} catch (InvalidName e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	} catch (NotFound e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	} catch (CannotProceed e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	} catch (org.omg.CosNaming.NamingContextPackage.InvalidName e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}

    }

}
