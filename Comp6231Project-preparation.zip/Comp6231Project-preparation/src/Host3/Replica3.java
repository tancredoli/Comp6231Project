package Host3;

import java.net.DatagramSocket;
import java.net.SocketException;
import java.rmi.RemoteException;
import java.util.Queue;

import Utility.Message;

public class Replica3 {

    public DEMSImpl MTL;
    public DEMSImpl OTW;
    public DEMSImpl TOR;
    DatagramSocket MTLSocket;
    DatagramSocket TORSocket;
    DatagramSocket OTWSocket;

    private boolean crash = false;
    public Queue<Message> historyQueue;

    String TOR_port = "1111";
    String MTL_port = "2222";
    String OTW_port = "3333";

    int TOR_udpportnum = 1112;
    int MTL_udpportnum = 2223;
    int OTW_udpportnum = 3334;

    // public Replica(DEMSImpl MTL, DEMSImpl OTW, DEMSImpl TOR) {
    // this.MTL = MTL;
    // this.OTW = OTW;
    // this.TOR = TOR;
    // }

    public Replica3() {
	try {

	    try {
		MTL = new DEMSImpl();
		TOR = new DEMSImpl();
		OTW = new DEMSImpl();
	    } catch (RemoteException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	    }

	    MTLSocket = new DatagramSocket(MTL_udpportnum);
	    TORSocket = new DatagramSocket(TOR_udpportnum);
	    OTWSocket = new DatagramSocket(OTW_udpportnum);
	} catch (SocketException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}
	startServers();

    }

    public boolean isCrash() {
	return crash;
    }

    public void setCrash(boolean crash) {
	this.crash = crash;
    }

    public Queue<Message> getHistoryQueue() {
	return historyQueue;
    }

    public void setHistoryQueue(Queue<Message> historyQueue) {
	this.historyQueue = historyQueue;
    }

    public String sendRequest(Message msg) {
	String resultS = "";
	boolean resultB = false;
	boolean flag = true;
	int seqId = msg.getSeqNum();
	String operation[] = msg.getOperationMsg().split(",");
	String userID = operation[1].substring(0, 3);
	DEMSImpl demsimpl = getImpl(userID);
	String type = "";
	String type1 = "";
	switch (operation[0]) {
	case ("addEvent"):
	    if (operation[3].equals("1")) {
		type = "conference";
	    } else if (operation[3].equals("2")) {
		type = "seminar";
	    } else {
		type = "tradeshow";
	    }
	    resultB = demsimpl.addEvent(operation[2], type, operation[1], Integer.parseInt(operation[4]));
	    if (resultB) {
		resultS = "T:";
	    } else {
		resultS = "F:";
	    }
	    break;
	case ("removeEvent"):
	    if (operation[3].equals("1")) {
		type = "conference";
	    } else if (operation[3].equals("2")) {
		type = "seminar";
	    } else {
		type = "tradeshow";
	    }
	    resultB = demsimpl.removeEvent(operation[2], type, operation[1]);
	    if (resultB) {
		resultS = "T:";
	    } else {
		resultS = "F:";
	    }
	    break;
	case ("listEventAvailability"):
	    if (operation[2].equals("1")) {
		type = "conference";
	    } else if (operation[2].equals("2")) {
		type = "seminar";
	    } else {
		type = "tradeshow";
	    }
	    resultS = demsimpl.listEventA(operation[1], type);
	    if (resultS.equals("")) {
		resultS = "NULL";
	    }
	    flag = false;
	    break;
	case ("bookEvent"):
	    if (operation[3].equals("1")) {
		type = "conference";
	    } else if (operation[3].equals("2")) {
		type = "seminar";
	    } else {
		type = "tradeshow";
	    }
	    resultB = demsimpl.bookEvent(operation[1], operation[2], type);
	    if (resultB) {
		resultS = "T:";
	    } else {
		resultS = "F:";
	    }
	    break;
	case ("getBookingSchedule"):
	    resultS = demsimpl.getBookingSchedule(operation[1]);
	    if (resultS.equals("")) {
		resultS = "NULL";
	    }
	    flag = false;
	    break;
	case ("cancelEvent"):
	    if (operation[3].equals("1")) {
		type = "conference";
	    } else if (operation[3].equals("2")) {
		type = "seminar";
	    } else {
		type = "tradeshow";
	    }
	    resultB = demsimpl.cancelEvent(operation[1], operation[2], type);
	    if (resultB) {
		resultS = "T:";
	    } else {
		resultS = "F:";
	    }
	    break;
	case ("swapEvent"):
	    if (operation[3].equals("1")) {
		type = "conference";
	    } else if (operation[3].equals("2")) {
		type = "seminar";
	    } else {
		type = "tradeshow";
	    }
	    if (operation[5].equals("1")) {
		type1 = "conference";
	    } else if (operation[5].equals("2")) {
		type1 = "seminar";
	    } else {
		type1 = "tradeshow";
	    }
	    resultB = demsimpl.swapEvent(operation[1], operation[2], type, operation[4], type1);
	    if (resultB) {
		resultS = "T:";
	    } else {
		resultS = "F:";
	    }
	    break;

	default:
	    System.out.println("Invalid input please try again.");
	    break;
	}
	if (seqId <= 2 && flag == true) {
	    if (resultS.equals("T:")) {
		resultS = "F:";
	    } else {
		resultS = "T:";
	    }
	}

	return resultS;
    }

    private static void startlistening(String City, DEMSImpl cityServer, int UDPlistenPort, DatagramSocket SeverSocket)
	    throws Exception {
	String threadName = City + "listen";
	Listening listen = new Listening(threadName, SeverSocket, cityServer);
	listen.start();
    }

    private DEMSImpl getImpl(String city) {
	if (city.equalsIgnoreCase("TOR"))
	    return this.TOR;
	else if (city.equalsIgnoreCase("MTL"))
	    return this.MTL;
	else
	    return this.OTW;
    }

    public void startServers() {
	Runnable start_TOR_UDP = () -> {
	    try {
		startlistening("TOR", TOR, TOR_udpportnum, TORSocket);
		TOR.StartServer("TOR");

	    } catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	    }
	};

	Runnable start_MTL_UDP = () -> {
	    try {
		startlistening("MTL", MTL, MTL_udpportnum, MTLSocket);
		MTL.StartServer("MTL");

	    } catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	    }
	};

	Runnable start_OTW_UDP = () -> {
	    try {
		startlistening("OTW", OTW, OTW_udpportnum, OTWSocket);
		OTW.StartServer("OTW");
	    } catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	    }
	};

	Thread Thread1 = new Thread(start_TOR_UDP);
	Thread Thread2 = new Thread(start_MTL_UDP);
	Thread Thread3 = new Thread(start_OTW_UDP);

	Thread1.start();
	Thread2.start();
	Thread3.start();
    }

    public void recoverRplicaData() {
	try {
	    MTL = new DEMSImpl();
	    TOR = new DEMSImpl();
	    OTW = new DEMSImpl();
	} catch (RemoteException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}
	startServers();
	while (historyQueue.size() > 0) {
	    Message msg = historyQueue.poll();
	    System.out.println("recover --> " + msg.getOperationMsg());
	    sendRequest(msg);
	}

    }
}
