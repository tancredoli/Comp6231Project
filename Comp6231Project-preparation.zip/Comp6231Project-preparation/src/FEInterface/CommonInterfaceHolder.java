package FEInterface;

public final class CommonInterfaceHolder implements org.omg.CORBA.portable.Streamable {
    public FEInterface.CommonInterface value = null;

    public CommonInterfaceHolder() {
    }

    public CommonInterfaceHolder(FEInterface.CommonInterface initialValue) {
	value = initialValue;
    }

    @Override
    public void _read(org.omg.CORBA.portable.InputStream i) {
	value = FEInterface.CommonInterfaceHelper.read(i);
    }

    @Override
    public void _write(org.omg.CORBA.portable.OutputStream o) {
	FEInterface.CommonInterfaceHelper.write(o, value);
    }

    @Override
    public org.omg.CORBA.TypeCode _type() {
	return FEInterface.CommonInterfaceHelper.type();
    }

}
