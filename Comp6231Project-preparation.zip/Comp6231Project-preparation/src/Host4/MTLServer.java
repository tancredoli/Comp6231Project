package Host4;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import Utility.UdpPort;

/**
 * @Author: Rui
 * @Description:
 * @Date: Created in 4:54 PM 2019-07-06
 * @Modified by:
 */
public class MTLServer extends Thread {

    private static final int fNumberOfThreads = 100;
    private static final Executor fThreadPool = Executors.newFixedThreadPool(fNumberOfThreads);
    public MTLImplementationClass obj;

    public MTLServer() {
	super();
	try {
	    this.obj = new MTLImplementationClass();
	} catch (Exception e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}
    }

    @Override
    public void run() {
	// TODO Auto-generated method stub
	super.run();

	Runnable task = () -> {
	    handleRequest(obj, UdpPort.mtlUdpPort);
	};

	fThreadPool.execute(task);

    }

    private static void handleRequest(MTLImplementationClass obj, int portNum) {
	DatagramSocket aSocket = null;
	try {
	    String result = "";
	    aSocket = new DatagramSocket(portNum);
	    byte[] buffer = new byte[1000];// to stored the received data from
	    // the client.
	    System.out.println("MTLUdpServer Started............");
	    while (true) {// non-terminating loop as the server is always
		// in listening mode.
		DatagramPacket request = new DatagramPacket(buffer, buffer.length);

		// Server waits for the request to come
		aSocket.receive(request);// request received

		String[] rs = new String(request.getData()).split("-");
		int requestType = Integer.parseInt(rs[0]);
		String userID = rs[1];
		int eventType = Integer.parseInt(rs[2]);
		String eventID = rs[3].trim();
		if (requestType == 0) {
		    if (eventType == 1) {
			result = obj.eventListHelper(obj.getConList());
		    } else if (eventType == 2) {
			result = obj.eventListHelper(obj.getSemList());
		    } else if (eventType == 3) {
			result = obj.eventListHelper(obj.getTsList());
		    }

		}
		if (requestType == 1) {
		    result = obj.getBookingScheduleHelper(userID);
		}
		if (requestType == 2) {
		    result = String.valueOf(obj.bookEventHelper(userID, eventID, eventType));
		}
		if (requestType == 3) {
		    result = String.valueOf(obj.cancelEventHelper(userID, eventID, eventType));
		}
		byte[] byteResult = result.getBytes();
		DatagramPacket reply = new DatagramPacket(byteResult, result.length(), request.getAddress(),
			request.getPort());// reply packet ready

		aSocket.send(reply);// reply sent
	    }
	} catch (SocketException e) {
	    System.out.println("Socket: " + e.getMessage());
	} catch (IOException e) {
	    System.out.println("IO: " + e.getMessage());
	} finally {
	    if (aSocket != null)
		aSocket.close();
	}
    }

}
