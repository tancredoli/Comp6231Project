package Host4;

import java.util.Queue;

import Utility.Message;

public class Replica4 {

    public boolean crash = false;
    public Queue<Message> historyQueue;

    private static final String strF = "F:";
    private static final String isTrue = "T:successfully";
    private static final String otherRs = "otherRs";
    public MTLServer mtlServer;
    public OTWServer otwServer;
    public TORServer torServer;

    public boolean isCrash() {
	return crash;
    }

    public void setCrash(boolean crash) {
	this.crash = crash;
    }

    public Queue<Message> getHistoryQueue() {
	return historyQueue;
    }

    public void setHistoryQueue(Queue<Message> historyQueue) {
	this.historyQueue = historyQueue;
    }

    public Replica4() {
	super();
	ReplicaStart();
    }

    public void ReplicaStart() {

	try {

	    mtlServer = new MTLServer();
	    otwServer = new OTWServer();
	    torServer = new TORServer();
	    mtlServer.start();
	    otwServer.start();
	    torServer.start();

	} catch (Exception e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}

    }

    public String sendRequest(Message msg) {
	String resultStr = "";
	boolean resultbool = false;
	int resultInt = -1;
	int seqId = msg.getSeqNum();
	String operation[] = msg.getOperationMsg().split(",");
	String userId = operation[1].substring(0, 3);
	Object server = null;
	boolean flag = true;
	switch (operation[0]) {
	case ("addEvent"):

	    if (userId.equalsIgnoreCase("MTL"))
		resultbool = mtlServer.obj.addEvent(operation[1], operation[2], Integer.parseInt(operation[3]),
			Integer.parseInt(operation[4]));
	    else if (userId.equalsIgnoreCase("OTW"))
		resultbool = otwServer.obj.addEvent(operation[1], operation[2], Integer.parseInt(operation[3]),
			Integer.parseInt(operation[4]));
	    else if (userId.equalsIgnoreCase("TOR"))
		resultbool = torServer.obj.addEvent(operation[1], operation[2], Integer.parseInt(operation[3]),
			Integer.parseInt(operation[4]));
	    if (resultbool) {
		resultStr = isTrue;
	    } else {
		resultStr = strF + "false";
	    }
	    break;
	case ("removeEvent"):
	    if (userId.equalsIgnoreCase("MTL"))
		resultbool = mtlServer.obj.removeEvent(operation[1], operation[2], Integer.parseInt(operation[3]));
	    else if (userId.equalsIgnoreCase("OTW"))
		resultbool = otwServer.obj.removeEvent(operation[1], operation[2], Integer.parseInt(operation[3]));
	    else if (userId.equalsIgnoreCase("TOR"))
		resultbool = torServer.obj.removeEvent(operation[1], operation[2], Integer.parseInt(operation[3]));
	    if (resultbool) {
		resultStr = isTrue;
	    } else {
		resultStr = strF + "false";
	    }
	    break;
	case ("listEventAvailability"):
	    if (userId.equalsIgnoreCase("MTL"))
		resultStr = mtlServer.obj.listEventAvailability(operation[1], Integer.parseInt(operation[2]));
	    else if (userId.equalsIgnoreCase("OTW"))
		resultStr = otwServer.obj.listEventAvailability(operation[1], Integer.parseInt(operation[2]));
	    else if (userId.equalsIgnoreCase("TOR"))
		resultStr = torServer.obj.listEventAvailability(operation[1], Integer.parseInt(operation[2]));
	    flag = false;
	    if (resultStr.isEmpty()) {
		resultStr = "NULL";

	    }
	    break;
	case ("bookEvent"):
	    if (userId.equalsIgnoreCase("MTL"))
		resultInt = mtlServer.obj.bookEvent(operation[1], operation[2], Integer.parseInt(operation[3]));
	    else if (userId.equalsIgnoreCase("OTW"))
		resultInt = otwServer.obj.bookEvent(operation[1], operation[2], Integer.parseInt(operation[3]));
	    else if (userId.equalsIgnoreCase("TOR"))
		resultInt = torServer.obj.bookEvent(operation[1], operation[2], Integer.parseInt(operation[3]));
	    if (resultInt == 0) {
		resultStr = isTrue;
	    } else if (resultInt == -1)
		resultStr = strF + "exit";
	    else if (resultInt == -2)
		resultStr = strF + "booked this";
	    else if (resultInt == -3)
		resultStr = strF + "full";
	    else
		resultStr = strF + otherRs;
	    break;
	case ("getBookingSchedule"):
	    if (userId.equalsIgnoreCase("MTL"))
		resultStr = mtlServer.obj.getBookingSchedule(operation[1]);
	    else if (userId.equalsIgnoreCase("OTW"))
		resultStr = otwServer.obj.getBookingSchedule(operation[1]);
	    else if (userId.equalsIgnoreCase("TOR"))
		resultStr = torServer.obj.getBookingSchedule(operation[1]);
	    if (resultStr.isEmpty()) {
		resultStr = "NULL";

	    }
	    flag = false;
	    break;
	case ("cancelEvent"):
	    if (userId.equalsIgnoreCase("MTL"))
		resultInt = mtlServer.obj.cancelEvent(operation[1], operation[2], Integer.parseInt(operation[3]));
	    else if (userId.equalsIgnoreCase("OTW"))
		resultInt = otwServer.obj.cancelEvent(operation[1], operation[2], Integer.parseInt(operation[3]));
	    else if (userId.equalsIgnoreCase("TOR"))
		resultInt = torServer.obj.cancelEvent(operation[1], operation[2], Integer.parseInt(operation[3]));
	    if (resultInt == 0) {
		resultStr = isTrue;
	    } else if (resultInt == -1)
		resultStr = strF + "booking_record";
	    else
		resultStr = strF + otherRs;
	    break;
	case ("swapEvent"):
	    if (userId.equalsIgnoreCase("MTL"))
		resultInt = mtlServer.obj.swapEvent(operation[1], operation[2], Integer.parseInt(operation[3]),
			operation[4], Integer.parseInt(operation[5]));
	    else if (userId.equalsIgnoreCase("OTW"))
		resultInt = otwServer.obj.swapEvent(operation[1], operation[2], Integer.parseInt(operation[3]),
			operation[4], Integer.parseInt(operation[5]));
	    else if (userId.equalsIgnoreCase("TOR"))
		resultInt = torServer.obj.swapEvent(operation[1], operation[2], Integer.parseInt(operation[3]),
			operation[4], Integer.parseInt(operation[5]));
	    if (resultInt == 0) {
		resultStr = isTrue;
	    } else if (resultInt == -2)
		resultStr = strF + "doesn't have booked";
	    else if (resultInt == -4)
		resultStr = strF + "have already booked";
	    else if (resultInt == -7)
		resultStr = strF + "booked 3";
	    else
		resultStr = strF + otherRs;
	    break;

	default:
	    System.out.println("Invalid input please try again.");
	    break;
	}

	return resultStr;
    }

    public void recoverRplicaData() {
	mtlServer.obj.refresh();
	mtlServer.obj.refresh();
	mtlServer.obj.refresh();
	while (historyQueue.size() > 0) {
	    Message msg = historyQueue.poll();
	    System.out.println("recover --- " + msg.getOperationMsg());
	    sendRequest(msg);
	}
    }

}
