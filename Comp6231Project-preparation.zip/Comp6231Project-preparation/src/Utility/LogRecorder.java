package Utility;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @Author: Rui
 * @Description:
 * @Date: Created in 4:33 PM 2019-07-06
 * @Modified by:
 */
public class LogRecorder {
    private File serverDir;
    private SimpleDateFormat format;
    private File outputFile;

    public LogRecorder(int type) throws IOException {
	this.serverDir = new File(System.getProperty("user.dir"));
	this.format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	String filename = new String();
	if (type == 1) {
	    filename = serverDir.toString() + "\\Server_Side_Log\\Host4\\MTLLOG.txt";

	} else if (type == 2) {
	    filename = serverDir.toString() + "\\Server_Side_Log\\Host4\\OTWLOG.txt";

	} else if (type == 3) {
	    filename = serverDir.toString() + "\\Server_Side_Log\\Host4\\TORLOG.txt";

	} else if (type == 4) {
	    filename = serverDir.toString() + "\\Server_Side_Log\\Host4\\Client" + "\\Client.txt";

	} else if (type == 5) {

	    filename = serverDir.toString() + "\\FE_LOG" + "\\FELOG.txt";

	} else if (type == 6) {

	    filename = serverDir.toString() + "\\Sequencer_LOG" + "\\SequencerLOG.txt";

	}
	this.outputFile = new File(filename);
	if (!this.outputFile.exists()) {
	    if (!this.outputFile.getParentFile().exists())
		this.outputFile.getParentFile().mkdirs();
	    this.outputFile.createNewFile();

	}

    }

    public String paraConstructor(String managerID, String customerID, int eventType, String eventID,
	    int bookingCapacity) {

	String para = "";
	if (!managerID.isEmpty())
	    para += " managerID: " + managerID;
	if (!customerID.isEmpty())
	    para += " customerID: " + customerID;
	if (eventType == 1)
	    para += " eventType: Conference";
	else if (eventType == 2)
	    para += " eventType: Seminars";
	else if (eventType == 3)
	    para += " eventType: Trade Shows";
	if (!eventID.isEmpty())
	    para += " eventID: " + eventID;
	if (bookingCapacity != 0)
	    para += " bookingCapacity: " + bookingCapacity;

	return para;

    }

    public synchronized void writeNorLog(String parameter, String action, boolean comp, String response) {
	String date = format.format(new Date());
	String actionExecu;
	if (comp)
	    actionExecu = "Completed";
	else
	    actionExecu = "Failed";
	FileWriter fw;
	try {
	    fw = new FileWriter(outputFile.getAbsolutePath(), true);
	} catch (IOException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}
	PrintWriter pw = new PrintWriter(fw);
	pw.println("Date: " + date + " | Parameter: " + parameter + " | " + "Action:" + " " + action);
	pw.println("Action execution: " + actionExecu + " | Response: " + response);
	pw.close();
    }

    public synchronized void writeSeqLog(String actionExecu) throws IOException {

	String date = format.format(new Date());
	FileWriter fw = new FileWriter(outputFile.getAbsolutePath(), true);
	PrintWriter pw = new PrintWriter(fw);
	pw.println("Date: " + date + " | Action: " + actionExecu);
	pw.close();

    }

    public synchronized void writeFElog(String actionExecu) {
	String date = format.format(new Date());
	FileWriter fw;
	try {
	    fw = new FileWriter(outputFile.getAbsolutePath(), true);
	} catch (IOException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}
	PrintWriter pw = new PrintWriter(fw);
	pw.println("Date: " + date + " | Action: " + actionExecu);
	pw.close();

    }
}
