package Utility;

public class UdpPort {
    public static int mtlUdpPort = 7102;
    public static int otwUdpPort = 8102;
    public static int torUdpPort = 9102;
}
