package Utility;

/**
 * @Author: Rui
 * @Description:
 * @Date: Created in 8:06 PM 2019-07-28
 * @Modified by:
 */
public class Constants {

    public static final String separator_colon = ":";
    public static final String separator_comma = ",";
    public static final String separator_sup = "!";

    public static final int RM_NUM = 4;

}
