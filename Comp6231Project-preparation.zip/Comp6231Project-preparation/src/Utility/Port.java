package Utility;

/**
 * @Author: Rui
 * @Description:
 * @Date: Created in 4:35 PM 2019-07-28
 * @Modified by:
 */
public class Port {

    public static final String FRONTEND_IP = "132.205.46.181";
    public static final String SEQUENCER_IP = "132.205.46.181";
    public static final String REPLICA1_IP = "132.205.46.181";
    public static final String REPLICA2_IP = "132.205.46.181";
    public static final String REPLICA3_IP = "132.205.46.181";
    public static final String REPLICA4_IP = "132.205.46.181";

    public static final int FRONTEND_PORT = 5000;
    public static final int SEQUENCER_PORT = 5001;
    public static final int REPLICA_NOR_PORT = 6666;

}
