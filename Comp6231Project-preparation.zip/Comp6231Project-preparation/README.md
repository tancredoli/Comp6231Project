# Comp6231Project
Project of Comp 6231 in 2019 summer.

## Getting started
You can just add your source code in the directory A2Design.