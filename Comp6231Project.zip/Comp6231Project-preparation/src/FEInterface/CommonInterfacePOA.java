package FEInterface;

public abstract class CommonInterfacePOA extends org.omg.PortableServer.Servant
	implements FEInterface.CommonInterfaceOperations, org.omg.CORBA.portable.InvokeHandler {

    // Constructors

    private static java.util.Hashtable _methods = new java.util.Hashtable();
    // Type-specific CORBA::Object operations
    private static String[] __ids = { "IDL:FEInterface/CommonInterface:1.0" };

    static {
	_methods.put("addEvent", new java.lang.Integer(0));
	_methods.put("removeEvent", new java.lang.Integer(1));
	_methods.put("listEventAvailability", new java.lang.Integer(2));
	_methods.put("bookEvent", new java.lang.Integer(3));
	_methods.put("getBookingSchedule", new java.lang.Integer(4));
	_methods.put("cancelEvent", new java.lang.Integer(5));
	_methods.put("swapEvent", new java.lang.Integer(6));
    }

    @Override
    public org.omg.CORBA.portable.OutputStream _invoke(String $method, org.omg.CORBA.portable.InputStream in,
	    org.omg.CORBA.portable.ResponseHandler $rh) {
	org.omg.CORBA.portable.OutputStream out = null;
	java.lang.Integer __method = (java.lang.Integer) _methods.get($method);
	if (__method == null)
	    throw new org.omg.CORBA.BAD_OPERATION(0, org.omg.CORBA.CompletionStatus.COMPLETED_MAYBE);

	switch (__method.intValue()) {
	case 0: // FEInterface/CommonInterface/addEvent
	{
	    String userID = in.read_string();
	    String eventID = in.read_string();
	    int eventType = in.read_long();
	    int bookingCapacity = in.read_long();
	    boolean $result = false;
	    $result = this.addEvent(userID, eventID, eventType, bookingCapacity);
	    out = $rh.createReply();
	    out.write_boolean($result);
	    break;
	}

	case 1: // FEInterface/CommonInterface/removeEvent
	{
	    String userID = in.read_string();
	    String eventID = in.read_string();
	    int eventType = in.read_long();
	    boolean $result = false;
	    $result = this.removeEvent(userID, eventID, eventType);
	    out = $rh.createReply();
	    out.write_boolean($result);
	    break;
	}

	case 2: // FEInterface/CommonInterface/listEventAvailability
	{
	    String userID = in.read_string();
	    int eventType = in.read_long();
	    String $result = null;
	    $result = this.listEventAvailability(userID, eventType);
	    out = $rh.createReply();
	    out.write_string($result);
	    break;
	}

	case 3: // FEInterface/CommonInterface/bookEvent
	{
	    String customerID = in.read_string();
	    String eventID = in.read_string();
	    int eventType = in.read_long();
	    int $result = 0;
	    $result = this.bookEvent(customerID, eventID, eventType);
	    out = $rh.createReply();
	    out.write_long($result);
	    break;
	}

	case 4: // FEInterface/CommonInterface/getBookingSchedule
	{
	    String customerID = in.read_string();
	    String $result = null;
	    $result = this.getBookingSchedule(customerID);
	    out = $rh.createReply();
	    out.write_string($result);
	    break;
	}

	case 5: // FEInterface/CommonInterface/cancelEvent
	{
	    String customerID = in.read_string();
	    String eventID = in.read_string();
	    int eventType = in.read_long();
	    int $result = 0;
	    $result = this.cancelEvent(customerID, eventID, eventType);
	    out = $rh.createReply();
	    out.write_long($result);
	    break;
	}

	case 6: // FEInterface/CommonInterface/swapEvent
	{
	    String customerID = in.read_string();
	    String newEventID = in.read_string();
	    int newEventType = in.read_long();
	    String oldEventID = in.read_string();
	    int oldEventType = in.read_long();
	    int $result = 0;
	    $result = this.swapEvent(customerID, newEventID, newEventType, oldEventID, oldEventType);
	    out = $rh.createReply();
	    out.write_long($result);
	    break;
	}

	default:
	    throw new org.omg.CORBA.BAD_OPERATION(0, org.omg.CORBA.CompletionStatus.COMPLETED_MAYBE);
	}

	return out;
    } // _invoke

    @Override
    public String[] _all_interfaces(org.omg.PortableServer.POA poa, byte[] objectId) {
	return __ids.clone();
    }

    public CommonInterface _this() {
	return CommonInterfaceHelper.narrow(super._this_object());
    }

    public CommonInterface _this(org.omg.CORBA.ORB orb) {
	return CommonInterfaceHelper.narrow(super._this_object(orb));
    }

} // class CommonInterfacePOA
