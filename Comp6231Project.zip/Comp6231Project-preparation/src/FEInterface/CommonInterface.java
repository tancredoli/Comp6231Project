package FEInterface;

public interface CommonInterface
	extends CommonInterfaceOperations, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity {
} // interface CommonInterface
