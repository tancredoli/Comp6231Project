package FrontEnd;

import java.util.Scanner;

import org.omg.CORBA.ORB;
import org.omg.CosNaming.NameComponent;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;
import org.omg.PortableServer.POA;
import org.omg.PortableServer.POAHelper;

import FEInterface.CommonInterface;
import FEInterface.CommonInterfaceHelper;

public class FEServer {

    public static void main(String[] args) {

	try {
	    ORB orb = ORB.init(args, null);

	    POA rootpoa = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));
	    rootpoa.the_POAManager().activate();

	    FEImplementation feObj = new FEImplementation();
	    feObj.setOrb(orb);

	    org.omg.CORBA.Object ref = rootpoa.servant_to_reference(feObj);

	    CommonInterface href = CommonInterfaceHelper.narrow(ref);

	    org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");

	    NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);

	    NameComponent path[] = ncRef.to_name("frontend");
	    ncRef.rebind(path, href);

	    System.out.println("FrontEndServer is Started..........");

	    Runnable runnable = new Runnable() {

		@Override
		public void run() {
		    // TODO Auto-generated method stub
		    Scanner scanner = new Scanner(System.in);

		    String rString = scanner.nextLine();
		    while (true) {
			feObj.addEvent("OTWM4560", "OTWE080619", 1, 1);
			feObj.addEvent("OTWM4560", "OTWE110619", 1, 1);
			feObj.addEvent("MTLM9087", "MTLA090619", 1, 2);
			feObj.addEvent("MTLM9087", "MTLA080619", 3, 2);
			feObj.addEvent("MTLM9087", "MTLE230719", 2, 1);
			feObj.addEvent("MTLM9087", "MTLA230719", 3, 2);
			feObj.bookEvent("TORC1234", "OTWE080619", 1);
			feObj.bookEvent("TORC1234", "MTLA090619", 1);
			feObj.bookEvent("TORC1234", "MTLA080619", 3);
			feObj.swapEvent("TORC1234", "MTLA090619", 1, "MTLA080619", 3);
			// feObj.sendCrash(Integer.parseInt(rString));
			rString = scanner.nextLine();
		    }

		}
	    };
	    for (;;) {
		new Thread(runnable).start();
		orb.run();

	    }

	} catch (Exception e) {
	    System.err.println("ERROR: " + e);
	    e.printStackTrace(System.out);
	}

	System.out.println("FrontEndServer Exiting ...");
    }

}
